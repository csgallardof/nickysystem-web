<?php
class WPBakeryShortCode_VC_List_Item extends WPBakeryShortCode {
    public function outputTitle($title) {
        return '';
    }
}