<?php
class WPBakeryShortCode_VC_Heading extends WPBakeryShortCode {

}